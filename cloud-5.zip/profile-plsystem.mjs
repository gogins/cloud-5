import vm from 'node:vm';
import fsSync from 'node:fs';

const CsoundACMock = await (async () => {
  class Event {
    clone() { return new Event(); }
    setTime(v) { this._t = v; } setDuration(v) { this._d = v; }
    setStatus() {} setInstrument(v) { this._ins = v; } setKey(v) { this._key = v; }
    setVelocity() {} setPan() {}
    getTime() { return this._t || 0; } getDuration() { return this._d || 1; }
    getOffTime() { return this.getTime() + this.getDuration(); }
    setOffTime(t) { this.setDuration(t - this.getTime()); }
    getInstrument() { return this._ins || 1; } getKey() { return this._key || 60; }
    getVelocity() { return 80; } getPan() { return 0; }
    toString() { return `Event(${this.getTime()})`; }
  }
  class Chord {
    clone() { return new Chord(); }
    resize() {} setPitch() {} getPitch() { return 60; }
    voices() { return 3; }
    T() { return this; } I() { return this; } K() { return this; } eI() { return this; }
    setInstrument() {} setDuration() {} information() { return ''; }
    epcs() { return this; }
  }
  let noteCount = 0;
  let conformCalls = 0;
  let tieCalls = 0;
  return {
    Event, Chord,
    resetNoteCount() { noteCount = 0; conformCalls = 0; tieCalls = 0; },
    get noteCount() { return noteCount; },
    get conformCalls() { return conformCalls; },
    get tieCalls() { return tieCalls; },
    Scale: class { clone() { return new this.constructor(); } resize() {} setPitch() {} },
    ChordScore: class {
      append_event() { noteCount++; }
      insertChord() {}
      insertChordWithMode() {}
      insertFunctionalHarmony() {}
      sort() {}
      findScale() { return this; }
      conformToChords() { conformCalls++; }
      tieOverlappingNotes() { tieCalls++; }
      getCsoundScore() { return ''; }
      size() { return noteCount; }
      get(i) {
        const e = new Event();
        e.setTime(i * 0.01);
        e.setDuration(0.5);
        e.setInstrument(2);
        e.setKey(60 + (i % 12));
        return e;
      }
      setScale() {} temper() {} setDuration() {}
      getScaleActualMinima() { return { toString() { return '0'; } }; }
      getScaleActualRanges() { return { toString() { return '1'; } }; }
    },
    PITV: class {
      initialize() {}
      fromChord() { return { P: 0, I: 0, T: 0, V: 0 }; }
      toChord() { return { revoicing: new Chord() }; }
      range = 12;
    },
    chordForName() { return new Chord(); },
    voiceleadingClosestRange(_a, b) { return b; },
    HarmonyConformMode: { Default: 0, Hc: 1, Hcv: 2, Hcs: 3, Hd: 4, Hds: 5 },
    insert() {},
  };
})();

const sandbox = {
  window: {},
  createCsoundAC: async () => CsoundACMock,
  CsoundAC: CsoundACMock,
  kustom: (t_, k_) => Math.sin(t_ * 40) * k_,
  console: { ...console, log() {}, info() {}, warn() {}, error: console.error },
  Math, parseFloat, setTimeout,
  numeric: {
    mul: (a) => a, add: (a) => a,
    identity: (n) => Array.from({ length: n }, () => Array(n).fill(0)),
    dotVM: (a) => a,
  },
};
sandbox.window = sandbox;

await vm.runInContext(fsSync.readFileSync('PLSystem.js', 'utf8'), vm.createContext(sandbox));
await new Promise((r) => setTimeout(r, 100));

const PLSystem = sandbox.PLSystem;
const CsoundAC = sandbox.CsoundAC;

function makeLsys(useHcs) {
  const hc = useHcs ? 'Hcs' : 'Hc';
  const lsys = new PLSystem.PLSystem();
  lsys.pitv.initialize(3, 72, 1, false);
  lsys.set_axiom('Hc 3; n = 1, 1.5, 144, 1, 1, 1, 0; Wn;');
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration<3)', `
        n = t/2.00+0.00, d/2.00+0, s, c/2+0.000, k/2.00+(t % 6), v/2.00+0.02, x/2+0; Wn;
  T -4; Hcs 3; n = t/2.10+1.00, d/2.00+0, s, c/2+0.000, k/-2.00+0.00, v/2.00+0.00, x/2+0; Wn;
  T 5; Hc 3;
  K; Hc 3; n = t/2.10+1.00, d/-2.00+0, s, c/2+1.100, k/2.00+1.90, v/2.00+3.00, x/2+0; Wn;
  `);
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration==3)', `
        m * 0, 2.0;
        m * 4, 2.0;
  T -4; Hc 3; n = t/1.50-0.50, d/1.50+0, s, c/2+0.000, k/2.00-0.10, v/2.00+0.00, x/2+0; Wn;
  T 5; Hc 3;
        n = t/1.50+0.00, d/2.00+0, s, c/2-1.000, k/2.20+0.80, v/2.00+0.00, x/2+0; Wn;
        K; Hcs 3; n = t/1.50+0.55, d/2.00+0, s, c/2+0.000, kustom(t,k), v/2.00+0.00, x/2+0; Wn;
        m * 0, 0.5;
        m * 4, 0.5;
  `);
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration>3 && (t % 8 < 1))', `
        n = t/2.20+0.00, d/2.00+0, s, c/2+0.000, k/2.00+0.02, v/2.00+0.02, x/2+0; Wn;
        T -4; Hc 3; n = t/2.10+1.00, d/2.00+0, s, c/2+0.000, k/2.00+0.03, v/2.00+0.00, x/2+0; Wn;
        K; Hc 3; n = t/2.10+1.00, d/2.00+0, s, c/2+1.150, k/2.00+0.90, v/2.00+0.00, x/2+0; Wn;
  `);
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration>3 && (t % 8 >= 1))', `
        n = t/2.20+0.00, d/2.00+0, s, c/2+0.000, k/2.00+0.02, v/2.00+0.02, x/2+0; Wn;
        n = t/2.30+0.10, d/2.00+0, s, c/2+0.500, k/2.00+1.10, v/2.00+2.00, x/2+0; Wn;
        K; Hc 3; n = t/2.10+1.00, d/2.00+0, s, c/2+0.000, k/2.00+0.03, v/2.00+0.00, x/2+0; Wn;
        n = t/2.10+1.00, d/2.00+0, s, c/2+1.150, k/2.00+0.90, v/2.00+0.00, x/2+0; Wn;
  `);
  lsys.set_turtle(new PLSystem.Turtle(new CsoundAC.Event(), new CsoundAC.Chord(), new CsoundAC.Chord()));
  return lsys;
}

function plsRescaleDimension(score, dimension, minimum, range) {
  score.setScale(score, dimension, true, true, 0, score.size(), minimum, range);
}

function postProcess(lsys) {
  lsys.score.findScale();
  lsys.score.sort();
  plsRescaleDimension(lsys.score, 3, 1, 16);
  plsRescaleDimension(lsys.score, 4, 24, 88);
  plsRescaleDimension(lsys.score, 5, 70, 16);
  lsys.score.temper(12);
  lsys.conformToChords();
  lsys.score.tieOverlappingNotes(true);
  const scoreCount = lsys.score.size();
  for (let i = 0; i < scoreCount; i++) {
    const event = lsys.score.get(i);
    event.setPan(event.getInstrument());
    let minimum_gap = null;
    let minimum_gap_event = null;
    for (let j = i + 1; j < scoreCount - 1; j++) {
      const gap_event = lsys.score.get(j);
      const gap = gap_event.getTime() - event.getOffTime();
      if (gap <= 0) {
        minimum_gap = 0;
        minimum_gap_event = null;
        break;
      }
      if (minimum_gap == null || gap < minimum_gap) {
        minimum_gap = gap;
        minimum_gap_event = gap_event;
      }
    }
    if (minimum_gap_event !== null && minimum_gap > 0) {
      event.setOffTime(minimum_gap_event.getTime());
    }
  }
  for (let i = 0; i < scoreCount; i++) {
    const event = lsys.score.get(i);
    const instrument = Math.floor(event.getInstrument());
    const key = event.getKey();
    for (let j = i + 1; j < scoreCount; j++) {
      const overlap = lsys.score.get(j);
      if (key === overlap.getKey() && instrument === Math.floor(overlap.getInstrument()) && instrument === 2) {
        if (event.getOffTime() > overlap.getTime()) {
          const the_end = Math.max(event.getOffTime(), overlap.getOffTime());
          event.setOffTime(the_end);
          overlap.setOffTime(the_end);
        }
      }
    }
  }
  lsys.conformToChords();
  plsRescaleDimension(lsys.score, 7, 0.1, 0.8);
}

for (const iterations of [5]) {
  for (const label of ['Hc', 'Hcs']) {
    CsoundAC.resetNoteCount();
    const lsys = makeLsys(label === 'Hcs');
    let t0 = Date.now();
    lsys.generate(iterations);
    const genMs = Date.now() - t0;
    t0 = Date.now();
    postProcess(lsys);
    const postMs = Date.now() - t0;
    console.log(`iter=${iterations} ${label}: generate=${genMs}ms post=${postMs}ms notes=${CsoundAC.noteCount}`);
  }
}
