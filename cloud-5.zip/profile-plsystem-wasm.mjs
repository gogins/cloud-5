import vm from 'node:vm';
import fsSync from 'node:fs';
import { pathToFileURL } from 'node:url';

const sandbox = {
  window: globalThis,
  globalThis,
  createCsoundAC: null,
  CsoundAC: null,
  kustom: (t_, k_) => Math.sin(t_ * 40) * k_,
  console,
  Math,
  parseFloat,
  setTimeout,
  clearTimeout,
  document: { currentScript: { src: pathToFileURL('CsoundAC.js').href } },
};
sandbox.window = sandbox;

const createCsoundAC = (await import(pathToFileURL('./CsoundAC.js').href)).default;
sandbox.createCsoundAC = createCsoundAC;
sandbox.CsoundAC = await createCsoundAC();

await vm.runInContext(fsSync.readFileSync('PLSystem.js', 'utf8'), vm.createContext(sandbox));
await new Promise((r) => setTimeout(r, 200));

const PLSystem = sandbox.PLSystem;
const CsoundAC = sandbox.CsoundAC;

function makeLsys() {
  const lsys = new PLSystem.PLSystem();
  lsys.pitv.initialize(3, 72, 1, false);
  lsys.set_axiom('Hc 3; n = 1, 1.5, 144, 1, 1, 1, 0; Wn;');
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration<3)', `
        n = t/2.00+0.00, d/2.00+0, s, c/2+0.000, k/2.00+(t % 6), v/2.00+0.02, x/2+0; Wn;
  T -4; Hcs 3; n = t/2.10+1.00, d/2.00+0, s, c/2+0.000, k/-2.00+0.00, v/2.00+0.00, x/2+0; Wn;
  T 5; Hc 3;
  K; Hc 3; n = t/2.10+1.00, d/-2.00+0, s, c/2+1.100, k/2.00+1.90, v/2.00+3.00, x/2+0; Wn;
  `);
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration==3)', `
        m * 0, 2.0;
        m * 4, 2.0;
  T -4; Hc 3; n = t/1.50-0.50, d/1.50+0, s, c/2+0.000, k/2.00-0.10, v/2.00+0.00, x/2+0; Wn;
  T 5; Hc 3;
        n = t/1.50+0.00, d/2.00+0, s, c/2-1.000, k/2.20+0.80, v/2.00+0.00, x/2+0; Wn;
        K; Hcs 3; n = t/1.50+0.55, d/2.00+0, s, c/2+0.000, kustom(t,k), v/2.00+0.00, x/2+0; Wn;
        m * 0, 0.5;
        m * 4, 0.5;
  `);
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration>3 && (t % 8 < 1))', `
        n = t/2.20+0.00, d/2.00+0, s, c/2+0.000, k/2.00+0.02, v/2.00+0.02, x/2+0; Wn;
        T -4; Hc 3; n = t/2.10+1.00, d/2.00+0, s, c/2+0.000, k/2.00+0.03, v/2.00+0.00, x/2+0; Wn;
        K; Hc 3; n = t/2.10+1.00, d/2.00+0, s, c/2+1.150, k/2.00+0.90, v/2.00+0.00, x/2+0; Wn;
  `);
  lsys.add_rule('n = t, d, s, c, k, v, x;', '(iteration>3 && (t % 8 >= 1))', `
        n = t/2.20+0.00, d/2.00+0, s, c/2+0.000, k/2.00+0.02, v/2.00+0.02, x/2+0; Wn;
        n = t/2.30+0.10, d/2.00+0, s, c/2+0.500, k/2.00+1.10, v/2.00+2.00, x/2+0; Wn;
        K; Hc 3; n = t/2.10+1.00, d/2.00+0, s, c/2+0.000, k/2.00+0.03, v/2.00+0.00, x/2+0; Wn;
        n = t/2.10+1.00, d/2.00+0, s, c/2+1.150, k/2.00+0.90, v/2.00+0.00, x/2+0; Wn;
  `);
  const chord = CsoundAC.chordForName('Gm');
  lsys.set_turtle(new PLSystem.Turtle(new CsoundAC.Event(), chord, chord));
  return lsys;
}

function plsRescaleDimension(score, dimension, minimum, range) {
  score.setScale(score, dimension, true, true, 0, score.size(), minimum, range);
}

function gapLoop(score, scoreCount) {
  for (let i = 0; i < scoreCount; i++) {
    const event = score.get(i);
    event.setPan(event.getInstrument());
    let minimum_gap = null;
    let minimum_gap_event = null;
    for (let j = i + 1; j < scoreCount - 1; j++) {
      const gap_event = score.get(j);
      const gap = gap_event.getTime() - event.getOffTime();
      if (gap <= 0) {
        minimum_gap = 0;
        minimum_gap_event = null;
        break;
      }
      if (minimum_gap == null || gap < minimum_gap) {
        minimum_gap = gap;
        minimum_gap_event = gap_event;
      }
    }
    if (minimum_gap_event !== null && minimum_gap > 0) {
      event.setOffTime(minimum_gap_event.getTime());
    }
  }
}

function overlapLoop(score, scoreCount) {
  for (let i = 0; i < scoreCount; i++) {
    const event = score.get(i);
    const instrument = Math.floor(event.getInstrument());
    const key = event.getKey();
    for (let j = i + 1; j < scoreCount; j++) {
      const overlap = score.get(j);
      if (key === overlap.getKey() && instrument === Math.floor(overlap.getInstrument()) && instrument === 2) {
        if (event.getOffTime() > overlap.getTime()) {
          const the_end = Math.max(event.getOffTime(), overlap.getOffTime());
          event.setOffTime(the_end);
          overlap.setOffTime(the_end);
        }
      }
    }
  }
}

for (const iterations of [5]) {
  const lsys = makeLsys();
  let t0 = performance.now();
  lsys.generate(iterations);
  console.log(`generate(${iterations}): ${(performance.now() - t0).toFixed(0)}ms notes=${lsys.score.size()}`);

  lsys.score.findScale();
  lsys.score.sort();

  t0 = performance.now();
  plsRescaleDimension(lsys.score, 3, 1, 16);
  plsRescaleDimension(lsys.score, 4, 24, 88);
  plsRescaleDimension(lsys.score, 5, 70, 16);
  console.log(`rescale: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  lsys.score.temper(12);
  console.log(`temper: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  lsys.conformToChords();
  console.log(`conform1: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  lsys.score.tieOverlappingNotes(true);
  console.log(`tie: ${(performance.now() - t0).toFixed(0)}ms`);

  const scoreCount = lsys.score.size();
  t0 = performance.now();
  gapLoop(lsys.score, scoreCount);
  console.log(`gapLoop: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  overlapLoop(lsys.score, scoreCount);
  console.log(`overlapLoop: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  lsys.conformToChords();
  console.log(`conform2: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  plsRescaleDimension(lsys.score, 7, 0.1, 0.8);
  console.log(`pan rescale: ${(performance.now() - t0).toFixed(0)}ms`);

  t0 = performance.now();
  lsys.score.getCsoundScore();
  console.log(`getCsoundScore: ${(performance.now() - t0).toFixed(0)}ms`);
}
